library(sqldf)

clus_one <- sqldf("select sum(total_runs) as tr,sum(is_super_over) as tw,bowler,count(ball) as tb from mergeddata where over>15 group by bowler")

clus_two <-sqldf("select tr*1.0/tw as Average,tb*1.0/tw as Strike_Rate,Bowler from clus_one")

for(i in 1:length(clus_one$bowler)){
  if(is.na(clus_two$Average[i]))
    clus_two$Average[i]=clus_one$tr[i]
  if(is.na(clus_two$Strike_Rate[i]))
    clus_two$Strike_Rate[i]=clus_one$tb[i]
}

library(ggplot2)
attach(clus_two)
venueCluster <- kmeans(clus_two[,1:2 ], 3, nstart = 15)
venueCluster$cluster <- as.factor(venueCluster$cluster)
#irisCluster$centers
#nrow(df3)
library("plotly")
p <- ggplot(clus_two, aes(Average,Strike_Rate,label = bowler ,color = venueCluster$cluster)) + geom_point()
ggplotly(p)
venueCluster
