library(sqldf)
library(readr)
library(plyr)
library(sqldf)
library(ggplot2)
library(shiny)
matches <- read_csv("matches.csv")

#View(matches)
deliveries <- read_csv("deliveries.csv")
#data1<-as.data.frame(matches)

data7<-as.data.frame(matches)
data8<-as.data.frame(deliveries)
nrow(data7)
#y<-list()
for(i in 1:length(data7$win_by_runs)){
  if(data7$win_by_runs[i]!=0)
    data7$win_by_runs[i]=1
  else
    data7$win_by_runs[i]=0
}
for(i in 1:length(data7$win_by_wickets)){
  if(data7$win_by_wickets[i]!=0)
    data7$win_by_wickets[i]=1
  else
    data7$win_by_wickets[i]=0
}

#nrow(y)
#data7$winbyruns<-y
data7<-as.data.frame(data7)
print(data7)
nrow(data7)
class(data7)

#df1<-sqldf("SELECT venue,COUNT(distinct(id)) as number_of_matches  FROM data7  GROUP BY venue")
df2<-sqldf("SELECT id,venue,COUNT(distinct(id)) as number_of_matches,sum(win_by_runs) as number_of_matches_won_by_runs ,sum(win_by_wickets) as numberOfMatchesWonByWickets,(sum(win_by_runs)*1.0/COUNT(distinct(id))) probabiltyOfWinBattingFirst,((sum(win_by_wickets)*1.0/COUNT(distinct(id)))) as probabiltyOfWinBowlingFirst FROM data7  GROUP BY venue")
df3<-sqldf("select probabiltyOfWinBattingFirst,probabiltyOfWinBowlingFirst,venue from df2 ")
#print(df2)
attach(df3)
#plot(probabiltyOfWinBattingFirst,probabiltyOfWinBowlingFirst, main="Scatterplot Example",
#xlab="winbattingfirst ", ylab="winbowlingfirst ") 
#ggplot(df2, aes(probabiltyOfWinBattingFirst, probabiltyOfWinBowlingFirst, color = venue)) + geom_point()
#set.seed(10)
venueCluster <- kmeans(df3[,1:2 ], 3, nstart = 15)
venueCluster$cluster <- as.factor(venueCluster$cluster)
#irisCluster$centers
#nrow(df3)
library("plotly")
p <- ggplot(df3, aes(probabiltyOfWinBattingFirst, probabiltyOfWinBowlingFirst,label=venue, color = venueCluster$cluster)) + geom_point()
ggplotly(p)
venueCluster
#venueCluster<-kmeans(df3,centers = 3)
#
#gg <- qplot(probabiltyOfWinBattingFirst, probabiltyOfWinBowlingFirst, data=df3, colour=venueCluster$cluster)

#gg <- ggplotly(gg)
#venuecluster$centers
#plot(df3[venuecluster$cluster==1,],col="red")
#plot(df3[venuecluster$cluster==2,],col="blue")
#plot(df3[venuecluster$cluster==3,],col="green")
#library(plotly)

#plot_ly(df3, x = ~probabiltyOfWinBattingFirst, y = ~probabiltyOfWinBowlingFirst, type = 'scatter', mode = 'markers',
#             text = ~paste('venue:', venue))
